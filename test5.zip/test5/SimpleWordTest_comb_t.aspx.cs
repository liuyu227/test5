﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class SimpleWordTest_comb_t : System.Web.UI.Page
{
    int count;
    int corr;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            Session["count"] = 0;
            Session["corr"] = 0;

        }
    }

    protected void CBF110043_testBtn_Click(object sender, EventArgs e)
    {
        CBF110043_MV1.ActiveViewIndex = 1;
        showtxt();
    }
    void showtxt()
    {
        count = (int)Session["count"];
        CBF110043_input.Text = "";
        CBF110043_ch_hint.Text += CBF110043_DDL1.Items[count].Value;
        for (int i = 0; i < CBF110043_DDL1.Items[count].Text.Length; i++)
        {
            if (i == 0) CBF110043_input.Text += CBF110043_DDL1.Items[count].Text += "_";
        }
    }

    void Check()
    {
        count = (int)Session["count"];
        if (CBF110043_input.Text == CBF110043_DDL1.Items[count].Text)
        {
            corr = (int)Session["corr"];
            corr++;
            Session["corr"] = corr;
            CBF110043_ch_hint.Text = "答對了<br/>";
        }
        else
        {
            CBF110043_ch_hint.Text = $"答錯了!答案是{CBF110043_DDL1.Items[count].Text}<br/>";
        }

    }

    protected void CBF110043_DDL1_DataBound(object sender, EventArgs e)
    {
        Random r = new Random();
        for (int i = CBF110043_DDL1.Items.Count - 1; i > 0; i--)
        {
            int x = r.Next(CBF110043_DDL1.Items.Count - 1);
            int y = r.Next(CBF110043_DDL1.Items.Count - 1);
            if (x != y)
            {
                string ItemX = CBF110043_DDL1.Items[x].ToString();
                string ValueX = CBF110043_DDL1.Items[x].Value.ToString();
                string ItemY = CBF110043_DDL1.Items[y].ToString();
                string ValueY = CBF110043_DDL1.Items[y].Value.ToString();
                CBF110043_DDL1.Items.Remove(CBF110043_DDL1.Items[x]);
                CBF110043_DDL1.Items.Insert(x, new ListItem(ItemY, ValueY));
                CBF110043_DDL1.Items.Insert(y, new ListItem(ItemX, ValueX));
            }
            
        }
        for (int i = CBF110043_DDL1.Items.Count - 1; i > 9; i--)
        {
            CBF110043_DDL1.Items.Remove(CBF110043_DDL1.Items[i]);
        }



    }
    protected void CBF110043_nextQBtn_Click(object sender, EventArgs e)
    {
        CBF110043_input.Focus();
        Check();
        count = (int)Session["count"];
        count++;
        Session["count"] = count;
        if (count < 10) showtxt();
        else
        {
            corr = (int)Session["corr"];
            CBF110043_ch_hint.Text += $"總得分 : {corr * 10:2f}";
            CBF110043_ch_hint.Text = "結束";

        }
    }
}
